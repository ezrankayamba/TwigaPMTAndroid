package tz.co.nezatech.apps.twigapmt.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;
import com.google.android.gms.location.GeofencingEvent;

public class GeofenceReceiver extends BroadcastReceiver {
    private static final String TAG = GeofenceReceiver.class.getName();

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "onReceive triggered");
        GeofencingEvent geofencingEvent = GeofencingEvent.fromIntent(intent);
        if (geofencingEvent.hasError()) {
            String errorMessage = "Error: " + geofencingEvent.getErrorCode();
            Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
        } else {
            geofencingEvent.getTriggeringGeofences().forEach(geofence -> {
                Log.d(TAG, "Project: " + geofence.getRequestId());
                Toast.makeText(context, "Project: " + geofence.getRequestId(), Toast.LENGTH_LONG).show();
            });
        }
    }
}
